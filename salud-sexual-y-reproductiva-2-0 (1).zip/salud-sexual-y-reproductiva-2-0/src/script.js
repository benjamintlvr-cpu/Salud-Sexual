// Esperar a que todo el documento cargue completamente
document.addEventListener('DOMContentLoaded', () => {

    // Seleccionar el modal y el botón de cierre
    const modal = document.getElementById('welcome-modal');
    const closeBtn = document.getElementById('close-modal-btn');

    // Asegurar que el modal esté visible al cargar la página
    modal.style.display = 'flex';

    // Evento para cerrar la bienvenida al hacer clic en el botón
    closeBtn.addEventListener('click', () => {
        modal.style.opacity = '0';
        modal.style.transition = 'opacity 0.5s ease';
        
        // Eliminar del flujo visual después de la animación
        setTimeout(() => {
            modal.style.display = 'none';
        }, 500);
    });
});
// Función global para alternar entre las pestañas del menú
function switchTab(tabId) {
    // 1. Ocultar todos los contenidos de las pestañas
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => content.classList.remove('active-content'));

    // 2. Desactivar el estilo visual de todos los botones
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));

    // 3. Mostrar el contenido seleccionado
    document.getElementById(tabId).classList.add('active-content');

    // 4. Activar el botón de la pestaña que recibió el clic
    const clickedButton = Array.from(buttons).find(btn => btn.getAttribute('onclick').includes(tabId));
    if (clickedButton) {
        clickedButton.classList.add('active');
    }
}
